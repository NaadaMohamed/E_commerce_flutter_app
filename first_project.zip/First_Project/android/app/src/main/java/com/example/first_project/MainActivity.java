package com.example.first_project;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
